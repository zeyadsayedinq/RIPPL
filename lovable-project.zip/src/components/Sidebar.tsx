import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, Users, FolderOpen, Radio, ChevronDown } from "lucide-react";
import { useRole, type Role } from "@/lib/role-context";
import { motion } from "framer-motion";
import { useState } from "react";

const nav = [
  { to: "/", label: "Overview", icon: LayoutDashboard },
  { to: "/creators", label: "Creators", icon: Users },
  { to: "/assets", label: "Assets", icon: FolderOpen },
];

const roles: Role[] = ["Marketing Manager", "Team Member", "Client"];

export function Sidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { role, setRole } = useRole();
  const [open, setOpen] = useState(false);

  return (
    <aside className="glass sticky top-4 z-20 flex h-[calc(100vh-2rem)] w-64 shrink-0 flex-col gap-6 rounded-2xl p-5">
      <div className="flex items-center gap-3">
        <div className="relative grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[oklch(0.7_0.28_328)] to-[oklch(0.5_0.3_300)]">
          <Radio className="h-5 w-5 text-white" />
          <div className="absolute inset-0 rounded-xl bg-[oklch(0.7_0.28_328)] blur-xl opacity-40 -z-10" />
        </div>
        <div className="min-w-0">
          <div className="font-display text-sm font-bold uppercase tracking-widest">LATIFA</div>
          <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">2026 · ROLLOUT</div>
        </div>
      </div>

      <nav className="flex flex-col gap-1">
        {nav.map((n) => {
          const active = pathname === n.to;
          return (
            <Link
              key={n.to}
              to={n.to}
              className={`group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${active ? "text-white" : "text-muted-foreground hover:text-white"}`}
            >
              {active && (
                <motion.div
                  layoutId="nav-active"
                  className="absolute inset-0 rounded-xl bg-gradient-to-r from-[oklch(0.7_0.28_328)]/25 to-[oklch(0.5_0.3_300)]/10 border border-[oklch(0.7_0.28_328)]/30"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <n.icon className="relative h-4 w-4" />
              <span className="relative">{n.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto flex flex-col gap-2">
        <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Signed in as</div>
        <button
          onClick={() => setOpen(!open)}
          className="glass relative flex items-center justify-between rounded-xl px-3 py-2.5 text-sm"
        >
          <span className="truncate">{role}</span>
          <ChevronDown className={`h-4 w-4 transition-transform ${open ? "rotate-180" : ""}`} />
        </button>
        {open && (
          <div className="glass-strong flex flex-col rounded-xl p-1">
            {roles.map((r) => (
              <button
                key={r}
                onClick={() => { setRole(r); setOpen(false); }}
                className={`rounded-lg px-3 py-2 text-left text-sm hover:bg-white/5 ${r === role ? "text-[oklch(0.8_0.25_328)]" : "text-foreground"}`}
              >
                {r}
              </button>
            ))}
          </div>
        )}
      </div>
    </aside>
  );
}
