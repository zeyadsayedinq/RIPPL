export type Tier = "Featured" | "Mega" | "Macro" | "Mid" | "Micro";
export type Platform = "TikTok" | "Instagram" | "Facebook" | "YouTube";
export type Status = "Confirmed" | "Pending" | "Priced" | "Rejected";

export interface Creator {
  id: string;
  name: string;
  handle: string;
  platform: Platform;
  tier: Tier;
  followers: number;
  avgViews: number;
  engagement: number;
  price: number;
  status: Status;
  city: string;
}

export const creators: Creator[] = [
  { id: "1", name: "Zyad Elshazly", handle: "@zyad_elshazly", platform: "TikTok", tier: "Featured", followers: 4200000, avgViews: 1250000, engagement: 12.4, price: 42000, status: "Confirmed", city: "Cairo" },
  { id: "2", name: "Shehab", handle: "@shehab.official", platform: "Instagram", tier: "Mega", followers: 2800000, avgViews: 680000, engagement: 8.9, price: 28000, status: "Priced", city: "Alexandria" },
  { id: "3", name: "Pasmala", handle: "@pasmala", platform: "TikTok", tier: "Mega", followers: 2100000, avgViews: 540000, engagement: 10.2, price: 24000, status: "Confirmed", city: "Cairo" },
  { id: "4", name: "Bassant", handle: "@bassant.b", platform: "Instagram", tier: "Macro", followers: 890000, avgViews: 210000, engagement: 7.5, price: 12500, status: "Pending", city: "Giza" },
  { id: "5", name: "Nour Fathy", handle: "@nourfathy", platform: "TikTok", tier: "Macro", followers: 760000, avgViews: 190000, engagement: 9.1, price: 11000, status: "Confirmed", city: "Cairo" },
  { id: "6", name: "Karim Adel", handle: "@karim.adel", platform: "Instagram", tier: "Mid", followers: 320000, avgViews: 68000, engagement: 6.4, price: 5500, status: "Pending", city: "Mansoura" },
  { id: "7", name: "Layla Hassan", handle: "@laylahassan", platform: "TikTok", tier: "Mid", followers: 280000, avgViews: 72000, engagement: 8.2, price: 4800, status: "Priced", city: "Cairo" },
  { id: "8", name: "Omar Sherif", handle: "@omar.sherif", platform: "Instagram", tier: "Micro", followers: 82000, avgViews: 14000, engagement: 5.8, price: 1500, status: "Confirmed", city: "Alexandria" },
  { id: "9", name: "Malak Ibrahim", handle: "@malak.ib", platform: "TikTok", tier: "Micro", followers: 65000, avgViews: 18000, engagement: 7.1, price: 1200, status: "Pending", city: "Cairo" },
  { id: "10", name: "Youssef Amr", handle: "@yousef.amr", platform: "Instagram", tier: "Macro", followers: 620000, avgViews: 140000, engagement: 6.9, price: 9800, status: "Rejected", city: "Cairo" },
  { id: "11", name: "Habiba Tarek", handle: "@habiba.t", platform: "TikTok", tier: "Featured", followers: 3100000, avgViews: 890000, engagement: 11.3, price: 36000, status: "Priced", city: "Cairo" },
  { id: "12", name: "Mostafa Nabil", handle: "@m.nabil", platform: "Instagram", tier: "Mid", followers: 190000, avgViews: 42000, engagement: 6.1, price: 3800, status: "Pending", city: "Giza" },
];

export const rolloutPhases = [
  { name: "Teaser Drop", date: "Jan 14, 2026", status: "complete", progress: 100 },
  { name: "Lead Single", date: "Feb 28, 2026", status: "active", progress: 68 },
  { name: "Music Video", date: "Mar 20, 2026", status: "upcoming", progress: 32 },
  { name: "Pre-Save Push", date: "Apr 10, 2026", status: "upcoming", progress: 15 },
  { name: "Album Release", date: "May 8, 2026", status: "upcoming", progress: 5 },
  { name: "Tour Announce", date: "Jun 1, 2026", status: "upcoming", progress: 0 },
];

export const conversionTrend = [
  { day: "Mon", TikTok: 4200, Instagram: 2400, Facebook: 1800, YouTube: 3100 },
  { day: "Tue", TikTok: 5100, Instagram: 2800, Facebook: 1600, YouTube: 3400 },
  { day: "Wed", TikTok: 6800, Instagram: 3200, Facebook: 2100, YouTube: 3800 },
  { day: "Thu", TikTok: 8200, Instagram: 3600, Facebook: 1900, YouTube: 4200 },
  { day: "Fri", TikTok: 11400, Instagram: 4400, Facebook: 2400, YouTube: 5100 },
  { day: "Sat", TikTok: 14200, Instagram: 5200, Facebook: 2800, YouTube: 6300 },
  { day: "Sun", TikTok: 16800, Instagram: 6100, Facebook: 3200, YouTube: 7400 },
];

export const platformStats = [
  { name: "TikTok", followers: "8.4M", reach: "42.1M", growth: 24.6, color: "oklch(0.7 0.28 328)" },
  { name: "Instagram", followers: "5.2M", reach: "18.7M", growth: 12.3, color: "oklch(0.55 0.3 300)" },
  { name: "Facebook", followers: "3.1M", reach: "9.4M", growth: 4.8, color: "oklch(0.85 0.18 200)" },
  { name: "YouTube", followers: "2.8M", reach: "22.6M", growth: 18.1, color: "oklch(0.75 0.2 60)" },
];

export const influencerPipeline = [
  { stage: "Sourced", count: 142 },
  { stage: "Contacted", count: 97 },
  { stage: "Priced", count: 54 },
  { stage: "Confirmed", count: 31 },
  { stage: "Delivered", count: 12 },
];

export interface Asset {
  id: string;
  name: string;
  type: "Brief" | "Audio" | "Art" | "Video";
  version: string;
  updated: string;
  owner: string;
  comments: Comment[];
}
export interface Comment {
  id: string;
  author: string;
  role: string;
  text: string;
  time: string;
}

export const assets: Asset[] = [
  { id: "a1", name: "Lead Single — Master v1.2", type: "Audio", version: "v1.2", updated: "2h ago", owner: "Latifa", comments: [
    { id: "c1", author: "Marwan", role: "Producer", text: "Bumped low-end 2dB, check the drop at 1:24.", time: "2h ago" },
    { id: "c2", author: "Latifa", role: "Artist", text: "Love it. Ship for mastering.", time: "1h ago" },
  ]},
  { id: "a2", name: "Album Cover — Concept A", type: "Art", version: "v2.0", updated: "6h ago", owner: "Studio Noir", comments: [
    { id: "c3", author: "Client", role: "Client", text: "Warmer on the gradient?", time: "5h ago" },
  ]},
  { id: "a3", name: "TikTok Creator Brief", type: "Brief", version: "v1.4", updated: "1d ago", owner: "Sara", comments: [] },
  { id: "a4", name: "Teaser 15s Cut", type: "Video", version: "v3.1", updated: "1d ago", owner: "Edit Team", comments: [
    { id: "c4", author: "Zyad", role: "Creator", text: "Can I get vertical crop?", time: "12h ago" },
  ]},
  { id: "a5", name: "Press Kit EPK", type: "Brief", version: "v2.3", updated: "3d ago", owner: "PR", comments: [] },
  { id: "a6", name: "Music Video Storyboard", type: "Art", version: "v0.8", updated: "4d ago", owner: "Director", comments: [] },
];

export const viralTriggers = [
  "@zyad_elshazly reached 1M views on Teaser",
  "@pasmala trending #3 in Egypt",
  "Lead Single pre-saves crossed 210K",
  "@habiba.t duet chain hit 4.2M plays",
  "TikTok sound library — Latifa hook adopted by 8.4K creators",
  "Instagram Reels engagement +38% WoW",
  "@shehab.official story swipe-ups peaked at 12%",
];
