import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { SpotlightCard } from "@/components/SpotlightCard";
import { Marquee } from "@/components/Marquee";
import { MagneticButton } from "@/components/MagneticButton";
import { creators, rolloutPhases, conversionTrend, platformStats, influencerPipeline, viralTriggers } from "@/lib/mock-data";
import { useRole } from "@/lib/role-context";
import { Users, Clock, Tag, Layers, DollarSign, TrendingUp, Facebook, Instagram, Youtube, Music2, Sparkles, ArrowUpRight, CheckCircle2 } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, RadialBarChart, RadialBar, PolarAngleAxis } from "recharts";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Latifa 2026 · Rollout Command" },
      { name: "description", content: "Tech-noir marketing command center for Latifa's 2026 album rollout." },
      { property: "og:title", content: "Latifa 2026 · Rollout Command" },
      { property: "og:description", content: "Tech-noir marketing command center for Latifa's 2026 album rollout." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { canSeePrice } = useRole();
  const totalCreators = creators.length + 85;
  const pending = creators.filter((c) => c.status === "Pending").length + 18;
  const priced = creators.filter((c) => c.status === "Priced").length + 22;
  const tiers = 5;
  const totalValue = 505000;

  return (
    <AppShell>
      <Header />

      <section className="mt-6 grid grid-cols-12 gap-4">
        <MetricCard icon={Users} label="Total Creators" value={totalCreators} accent="magenta" span="col-span-6 md:col-span-3 lg:col-span-2" />
        <MetricCard icon={Clock} label="Pending" value={pending} accent="cyan" span="col-span-6 md:col-span-3 lg:col-span-2" />
        <MetricCard icon={Tag} label="Priced" value={priced} accent="purple" span="col-span-6 md:col-span-3 lg:col-span-2" />
        <MetricCard icon={Layers} label="Tiers" value={tiers} accent="magenta" span="col-span-6 md:col-span-3 lg:col-span-2" />
        <SpotlightCard className="col-span-12 lg:col-span-4 p-6">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-muted-foreground">
                <DollarSign className="h-3.5 w-3.5" /> Total Campaign Value
              </div>
              <div className="mt-3 font-display text-5xl font-bold text-gradient-neon">
                {canSeePrice ? `$${totalValue.toLocaleString()}` : "•••••"}
              </div>
              <div className="mt-2 flex items-center gap-2 text-xs text-[oklch(0.85_0.18_200)]">
                <TrendingUp className="h-3 w-3" /> +18.4% vs. Q4 forecast
              </div>
            </div>
            <div className="glass grid h-14 w-14 shrink-0 place-items-center rounded-xl">
              <Sparkles className="h-6 w-6 text-[oklch(0.7_0.28_328)]" />
            </div>
          </div>
        </SpotlightCard>
      </section>

      <div className="mt-6">
        <Marquee items={viralTriggers} />
      </div>

      <section className="mt-6 grid grid-cols-12 gap-4">
        <SpotlightCard className="col-span-12 xl:col-span-8 p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Main Campaign HUD</div>
              <h2 className="mt-1 font-display text-2xl font-bold">Platform Conversion · 7d</h2>
            </div>
            <MagneticButton variant="ghost">
              <ArrowUpRight className="h-4 w-4" /> Full report
            </MagneticButton>
          </div>

          <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-3">
            {platformStats.map((p) => (
              <PlatformTile key={p.name} name={p.name} followers={p.followers} reach={p.reach} growth={p.growth} color={p.color} />
            ))}
          </div>

          <div className="mt-6 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={conversionTrend}>
                <defs>
                  <linearGradient id="gTT" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.7 0.28 328)" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="oklch(0.7 0.28 328)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gIG" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.55 0.3 300)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="oklch(0.55 0.3 300)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gYT" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.75 0.2 60)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="oklch(0.75 0.2 60)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gFB" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.85 0.18 200)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="oklch(0.85 0.18 200)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" stroke="rgba(255,255,255,0.3)" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="rgba(255,255,255,0.3)" fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{ background: "rgba(15,5,25,0.9)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, backdropFilter: "blur(20px)" }}
                  labelStyle={{ color: "#fff" }}
                />
                <Area type="monotone" dataKey="TikTok" stroke="oklch(0.7 0.28 328)" strokeWidth={2} fill="url(#gTT)" />
                <Area type="monotone" dataKey="YouTube" stroke="oklch(0.75 0.2 60)" strokeWidth={2} fill="url(#gYT)" />
                <Area type="monotone" dataKey="Instagram" stroke="oklch(0.55 0.3 300)" strokeWidth={2} fill="url(#gIG)" />
                <Area type="monotone" dataKey="Facebook" stroke="oklch(0.85 0.18 200)" strokeWidth={2} fill="url(#gFB)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </SpotlightCard>

        <SpotlightCard className="col-span-12 xl:col-span-4 p-6">
          <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Influencer Campaign HUD</div>
          <h2 className="mt-1 font-display text-2xl font-bold">Pipeline</h2>

          <div className="mt-6 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart innerRadius="30%" outerRadius="100%" data={influencerPipeline} startAngle={180} endAngle={-180}>
                <PolarAngleAxis type="number" domain={[0, 150]} tick={false} />
                <RadialBar background={{ fill: "rgba(255,255,255,0.04)" }} dataKey="count" cornerRadius={8} fill="oklch(0.7 0.28 328)" />
                <Tooltip contentStyle={{ background: "rgba(15,5,25,0.9)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12 }} />
              </RadialBarChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-4 space-y-2">
            {influencerPipeline.map((s, i) => (
              <div key={s.stage} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 rounded-full" style={{ background: `oklch(0.7 0.28 ${328 - i * 15})` }} />
                  <span className="text-muted-foreground">{s.stage}</span>
                </div>
                <span className="font-mono text-foreground">{s.count}</span>
              </div>
            ))}
          </div>
        </SpotlightCard>
      </section>

      <section className="mt-6 grid grid-cols-12 gap-4">
        <SpotlightCard className="col-span-12 p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">2026 Rollout</div>
              <h2 className="mt-1 font-display text-2xl font-bold">Milestone Timeline</h2>
            </div>
            <div className="glass hidden sm:flex items-center gap-2 rounded-full px-3 py-1.5 text-xs">
              <span className="h-1.5 w-1.5 rounded-full bg-[oklch(0.7_0.28_328)] animate-pulse" />
              <span className="text-muted-foreground">Live sync</span>
            </div>
          </div>

          <div className="mt-8 relative">
            <div className="absolute left-0 right-0 top-6 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            <div className="relative grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {rolloutPhases.map((p) => (
                <div key={p.name} className="relative">
                  <div className="flex flex-col items-start">
                    <div className={`relative grid h-12 w-12 place-items-center rounded-full border-2 ${p.status === "complete" ? "border-[oklch(0.7_0.28_328)] bg-[oklch(0.7_0.28_328)]/20" : p.status === "active" ? "border-[oklch(0.85_0.18_200)] bg-[oklch(0.85_0.18_200)]/10" : "border-white/15 bg-white/[0.03]"}`}>
                      {p.status === "complete" ? <CheckCircle2 className="h-5 w-5 text-[oklch(0.85_0.25_328)]" /> : <span className="font-mono text-xs text-foreground">{p.progress}%</span>}
                      {p.status === "active" && <div className="absolute inset-0 rounded-full bg-[oklch(0.85_0.18_200)]/30 blur-md animate-pulse -z-10" />}
                    </div>
                    <div className="mt-3 text-sm font-semibold">{p.name}</div>
                    <div className="text-xs text-muted-foreground">{p.date}</div>
                    <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-white/5">
                      <div className="h-full rounded-full bg-gradient-to-r from-[oklch(0.7_0.28_328)] to-[oklch(0.55_0.3_300)]" style={{ width: `${p.progress}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </SpotlightCard>
      </section>
    </AppShell>
  );
}

function Header() {
  return (
    <header className="glass flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-2xl p-5">
      <div className="min-w-0">
        <div className="text-[10px] uppercase tracking-[0.35em] text-[oklch(0.85_0.25_328)]">Command · Overview</div>
        <h1 className="mt-1 font-display text-3xl font-bold tracking-tight">Rollout HQ / <span className="text-gradient-neon">Q1 2026</span></h1>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <MagneticButton variant="ghost">Export brief</MagneticButton>
        <MagneticButton>+ New campaign</MagneticButton>
      </div>
    </header>
  );
}

function MetricCard({ icon: Icon, label, value, accent, span }: { icon: any; label: string; value: number; accent: "magenta" | "purple" | "cyan"; span: string }) {
  const colors = {
    magenta: "oklch(0.7 0.28 328)",
    purple: "oklch(0.55 0.3 300)",
    cyan: "oklch(0.85 0.18 200)",
  };
  return (
    <SpotlightCard className={`${span} p-5`}>
      <div className="flex items-center justify-between">
        <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{label}</div>
        <Icon className="h-4 w-4" style={{ color: colors[accent] }} />
      </div>
      <div className="mt-3 font-display text-4xl font-bold">{value}</div>
      <div className="mt-1 h-0.5 w-8 rounded" style={{ background: colors[accent] }} />
    </SpotlightCard>
  );
}

function PlatformTile({ name, followers, reach, growth, color }: { name: string; followers: string; reach: string; growth: number; color: string }) {
  const iconMap: Record<string, any> = { TikTok: Music2, Instagram: Instagram, Facebook: Facebook, YouTube: Youtube };
  const Icon = iconMap[name];
  return (
    <div className="glass rounded-xl p-4">
      <div className="flex items-center justify-between">
        <Icon className="h-4 w-4" style={{ color }} />
        <span className="font-mono text-xs text-[oklch(0.85_0.18_200)]">+{growth}%</span>
      </div>
      <div className="mt-3 text-sm font-medium">{name}</div>
      <div className="mt-1 font-display text-xl font-bold">{followers}</div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Reach {reach}</div>
    </div>
  );
}
